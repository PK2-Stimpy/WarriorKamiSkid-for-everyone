// 
// Decompiled by Procyon v0.5.36
// 

package org.yaml.snakeyaml.external.com.google.gdata.util.common.base;

public interface Escaper
{
    String escape(final String p0);
    
    Appendable escape(final Appendable p0);
}
