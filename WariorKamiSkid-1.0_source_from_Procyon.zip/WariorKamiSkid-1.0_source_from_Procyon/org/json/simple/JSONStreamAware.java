// 
// Decompiled by Procyon v0.5.36
// 

package org.json.simple;

import java.io.IOException;
import java.io.Writer;

public interface JSONStreamAware
{
    void writeJSONString(final Writer p0) throws IOException;
}
